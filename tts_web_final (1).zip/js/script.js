/**
 * SpeakEasy - Free Text to Speech
 * Main JavaScript functionality
 */

document.addEventListener('DOMContentLoaded', () => {
    // Check if browser supports speech synthesis
    if (!('speechSynthesis' in window)) {
        alert('Your browser does not support speech synthesis. Please try Chrome, Edge, Safari, or Firefox.');
        disableInterface();
        return;
    }

    // DOM elements
    const textInput = document.getElementById('text-input');
    const fileInput = document.getElementById('file-input');
    const clearButton = document.getElementById('clear-text');
    const voiceSelect = document.getElementById('voice-select');
    const languageSelect = document.getElementById('language-select');
    const rateInput = document.getElementById('rate');
    const rateValue = document.getElementById('rate-value');
    const pitchInput = document.getElementById('pitch');
    const pitchValue = document.getElementById('pitch-value');
    const volumeInput = document.getElementById('volume');
    const volumeValue = document.getElementById('volume-value');
    const playButton = document.getElementById('play-button');
    const pauseButton = document.getElementById('pause-button');
    const stopButton = document.getElementById('stop-button');
    const downloadButton = document.getElementById('download-button');
    const statusMessage = document.getElementById('status-message');
    const progressContainer = document.getElementById('progress-container');
    const progressBar = document.getElementById('progress-bar');

    // Speech synthesis variables
    const synth = window.speechSynthesis;
    let voices = [];
    let currentUtterance = null;
    let mediaRecorder = null;
    let audioChunks = [];

    // Initialize voices
    function loadVoices() {
        voices = synth.getVoices();
        
        // Clear existing options
        voiceSelect.innerHTML = '';
        
        // Group voices by language
        const voicesByLang = {};
        const languages = new Set();
        
        voices.forEach(voice => {
            const langCode = voice.lang.split('-')[0];
            languages.add(langCode);
            
            if (!voicesByLang[voice.lang]) {
                voicesByLang[voice.lang] = [];
            }
            voicesByLang[voice.lang].push(voice);
        });
        
        // Populate voice select
        voices.forEach((voice, i) => {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = `${voice.name} (${voice.lang})`;
            if (voice.default) {
                option.textContent += ' — Default';
                option.selected = true;
            }
            voiceSelect.appendChild(option);
        });
        
        // Populate language select
        languageSelect.innerHTML = '<option value="">Auto-detect</option>';
        
        // Sort languages alphabetically
        const sortedLanguages = Array.from(languages).sort();
        
        sortedLanguages.forEach(langCode => {
            const option = document.createElement('option');
            option.value = langCode;
            
            // Get language name from first voice with this language code
            const langVoice = voices.find(v => v.lang.startsWith(langCode));
            const langName = new Intl.DisplayNames(['en'], { type: 'language' }).of(langCode);
            
            option.textContent = langName;
            languageSelect.appendChild(option);
        });
        
        updateStatus('Voices loaded. Ready to speak.');
    }

    // Load voices when available
    if (synth.onvoiceschanged !== undefined) {
        synth.onvoiceschanged = loadVoices;
    } else {
        loadVoices();
    }

    // Event listeners for controls
    rateInput.addEventListener('input', () => {
        rateValue.textContent = rateInput.value;
    });

    pitchInput.addEventListener('input', () => {
        pitchValue.textContent = pitchInput.value;
    });

    volumeInput.addEventListener('input', () => {
        volumeValue.textContent = volumeInput.value;
    });

    // File input handler
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        if (file.type !== 'text/plain') {
            updateStatus('Please select a text (.txt) file.');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = (e) => {
            textInput.value = e.target.result;
            updateStatus('Text loaded from file.');
        };
        reader.onerror = () => {
            updateStatus('Error reading file.');
        };
        reader.readAsText(file);
    });

    // Clear text button
    clearButton.addEventListener('click', () => {
        textInput.value = '';
        updateStatus('Text cleared.');
        textInput.focus();
    });

    // Play button
    playButton.addEventListener('click', () => {
        if (synth.speaking) {
            if (synth.paused) {
                synth.resume();
                updateStatus('Resumed speaking.');
                updatePlaybackButtons(true, false);
            }
            return;
        }
        
        const text = textInput.value.trim();
        if (!text) {
            updateStatus('Please enter some text to speak.');
            return;
        }
        
        speak(text);
    });

    // Pause button
    pauseButton.addEventListener('click', () => {
        if (synth.speaking && !synth.paused) {
            synth.pause();
            updateStatus('Paused speaking.');
            updatePlaybackButtons(true, true);
        }
    });

    // Stop button
    stopButton.addEventListener('click', () => {
        if (synth.speaking) {
            synth.cancel();
            updateStatus('Stopped speaking.');
            updatePlaybackButtons(false, false);
        }
    });

    // Download button
    downloadButton.addEventListener('click', () => {
        const text = textInput.value.trim();
        if (!text) {
            updateStatus('Please enter some text to convert to speech.');
            return;
        }
        
        // Start recording and then speak
        startRecording().then(() => {
            speak(text, true);
        }).catch(error => {
            updateStatus('Error: ' + error.message);
        });
    });

    // Main speak function
    function speak(text, isRecording = false) {
        // Cancel any ongoing speech
        if (synth.speaking) {
            synth.cancel();
        }
        
        // Create a new utterance
        currentUtterance = new SpeechSynthesisUtterance(text);
        
        // Set voice
        const selectedVoice = voices[voiceSelect.value];
        if (selectedVoice) {
            currentUtterance.voice = selectedVoice;
        }
        
        // Set language if manually selected
        if (languageSelect.value) {
            currentUtterance.lang = languageSelect.value;
        }
        
        // Set other properties
        currentUtterance.rate = parseFloat(rateInput.value);
        currentUtterance.pitch = parseFloat(pitchInput.value);
        currentUtterance.volume = parseFloat(volumeInput.value);
        
        // Event listeners
        currentUtterance.onstart = () => {
            updateStatus('Speaking...');
            updatePlaybackButtons(true, false);
            progressContainer.classList.remove('hidden');
        };
        
        currentUtterance.onend = () => {
            updateStatus('Finished speaking.');
            updatePlaybackButtons(false, false);
            progressContainer.classList.add('hidden');
            progressBar.style.width = '0%';
            
            if (isRecording) {
                stopRecording();
            }
        };
        
        currentUtterance.onerror = (event) => {
            updateStatus('Error occurred while speaking: ' + event.error);
            updatePlaybackButtons(false, false);
            progressContainer.classList.add('hidden');
            
            if (isRecording) {
                stopRecording();
            }
        };
        
        currentUtterance.onpause = () => {
            updateStatus('Speech paused.');
        };
        
        currentUtterance.onresume = () => {
            updateStatus('Speech resumed.');
        };
        
        currentUtterance.onboundary = (event) => {
            // Update progress bar based on character position
            if (text.length > 0) {
                const progress = (event.charIndex / text.length) * 100;
                progressBar.style.width = `${Math.min(progress, 100)}%`;
            }
        };
        
        // Start speaking
        synth.speak(currentUtterance);
    }

    // Recording functions for download
    async function startRecording() {
        // Reset audio chunks
        audioChunks = [];
        
        // Create audio context and destination
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const destination = audioContext.createMediaStreamDestination();
        
        // Create media recorder
        try {
            mediaRecorder = new MediaRecorder(destination.stream);
        } catch (error) {
            throw new Error('Your browser does not support audio recording: ' + error.message);
        }
        
        // Set up event listeners
        mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
                audioChunks.push(event.data);
            }
        };
        
        mediaRecorder.onstop = () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/mp3' });
            const audioUrl = URL.createObjectURL(audioBlob);
            
            // Create download link
            const a = document.createElement('a');
            a.href = audioUrl;
            a.download = 'speech.mp3';
            a.style.display = 'none';
            document.body.appendChild(a);
            a.click();
            
            // Clean up
            setTimeout(() => {
                document.body.removeChild(a);
                URL.revokeObjectURL(audioUrl);
            }, 100);
            
            updateStatus('Audio file downloaded.');
        };
        
        // Start recording
        mediaRecorder.start();
        updateStatus('Recording started...');
    }

    function stopRecording() {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
        }
    }

    // Helper functions
    function updateStatus(message) {
        statusMessage.textContent = message;
    }

    function updatePlaybackButtons(isSpeaking, isPaused) {
        if (isSpeaking) {
            playButton.disabled = isPaused ? false : true;
            pauseButton.disabled = isPaused ? true : false;
            stopButton.disabled = false;
            downloadButton.disabled = true;
        } else {
            playButton.disabled = false;
            pauseButton.disabled = true;
            stopButton.disabled = true;
            downloadButton.disabled = false;
        }
    }

    function disableInterface() {
        textInput.disabled = true;
        fileInput.disabled = true;
        clearButton.disabled = true;
        voiceSelect.disabled = true;
        languageSelect.disabled = true;
        rateInput.disabled = true;
        pitchInput.disabled = true;
        volumeInput.disabled = true;
        playButton.disabled = true;
        pauseButton.disabled = true;
        stopButton.disabled = true;
        downloadButton.disabled = true;
        updateStatus('Speech synthesis is not supported in your browser.');
    }
});
