/**
 * SpeakEasy - Advertising System
 * JavaScript for ad functionality
 */

document.addEventListener('DOMContentLoaded', () => {
    // DOM elements
    const downloadButton = document.getElementById('download-button');
    const adModal = document.getElementById('ad-modal');
    const privacyModal = document.getElementById('privacy-modal');
    const privacyPolicyLink = document.getElementById('privacy-policy-link');
    const termsLink = document.getElementById('terms-link');
    const adChoicesLink = document.getElementById('ad-choices-link');
    const closeModalButtons = document.querySelectorAll('.close-modal');
    const countdownElement = document.getElementById('countdown');
    
    // Initialize cookie consent
    window.cookieconsent.initialise({
        palette: {
            popup: {
                background: "#5F6368",
                text: "#ffffff"
            },
            button: {
                background: "#4285F4",
                text: "#ffffff"
            }
        },
        theme: "classic",
        position: "bottom-right",
        content: {
            message: "This website uses cookies to ensure you get the best experience and to display relevant ads.",
            dismiss: "Got it!",
            link: "Learn more",
            href: "#privacy-policy"
        },
        elements: {
            link: function(element) {
                element.addEventListener('click', function(e) {
                    e.preventDefault();
                    showModal(privacyModal);
                });
            }
        }
    });
    
    // Ad system initialization
    function initAdSystem() {
        // Simulate ad loading
        const adContainers = document.querySelectorAll('.ad-container');
        adContainers.forEach(container => {
            // In a real implementation, this would be replaced with actual ad network code
            const placeholder = container.querySelector('.ad-placeholder');
            if (placeholder) {
                placeholder.innerHTML = `<div class="ad-placeholder-text">${placeholder.querySelector('.ad-placeholder-text').textContent}</div>`;
            }
        });
        
        // Log ad impressions (would be replaced with actual tracking in production)
        console.log('Ad impressions logged:', adContainers.length);
    }
    
    // Show pre-download ad modal
    function showPreDownloadAd() {
        showModal(adModal);
        startCountdown();
    }
    
    // Start countdown for download
    function startCountdown() {
        let seconds = 5;
        countdownElement.textContent = seconds;
        
        const interval = setInterval(() => {
            seconds--;
            countdownElement.textContent = seconds;
            
            if (seconds <= 0) {
                clearInterval(interval);
                hideModal(adModal);
                // Trigger the actual download
                triggerDownload();
            }
        }, 1000);
    }
    
    // Trigger the actual download functionality
    function triggerDownload() {
        // This would call the original download function
        // For now, we'll just log it
        console.log('Download triggered after ad view');
        
        // In a real implementation, this would call the original download function
        // that was in the script.js file
    }
    
    // Show modal
    function showModal(modal) {
        modal.classList.remove('hidden');
    }
    
    // Hide modal
    function hideModal(modal) {
        modal.classList.add('hidden');
    }
    
    // Event listeners
    downloadButton.addEventListener('click', (e) => {
        e.preventDefault();
        // Instead of downloading immediately, show the ad first
        showPreDownloadAd();
    });
    
    privacyPolicyLink.addEventListener('click', (e) => {
        e.preventDefault();
        showModal(privacyModal);
    });
    
    termsLink.addEventListener('click', (e) => {
        e.preventDefault();
        // In a real implementation, this would show a terms modal
        alert('Terms of Use would be displayed here.');
    });
    
    adChoicesLink.addEventListener('click', (e) => {
        e.preventDefault();
        // In a real implementation, this would link to ad choices page
        alert('Ad Choices information would be displayed here.');
    });
    
    closeModalButtons.forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.modal');
            hideModal(modal);
        });
    });
    
    // Initialize ad system
    initAdSystem();
    
    // Override the original download function in script.js
    // This assumes there's a global downloadAudio function
    if (window.downloadAudio) {
        const originalDownloadFunction = window.downloadAudio;
        window.downloadAudio = function() {
            showPreDownloadAd();
        };
    }
});
